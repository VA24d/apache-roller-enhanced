# Task 5: Web Translation and Caching

## 1. Feature Description

Task 5 adds a translation subsystem for public Roller weblog pages and combines it with section-level caching so repeated translations do not always call an external provider again. The feature lets a reader open a public weblog page, choose a source language, target language, and provider from a floating translation widget, and translate the visible weblog text without changing the page structure.

The implemented scope covers theme-driven public pages that include the shared translation widget. In this repository, the widget is wired into public weblog, permalink, search, tags, archives, and frontpage views across the shipped themes. The backend is generic enough to support more views later if those views adopt the same frontend contract.

The main user-visible capabilities are:

- Translation of already rendered weblog text on public pages.
- Runtime switching between `MyMemory` and `Sarvam AI`.
- Marathi support in both the UI and backend normalization layer.
- Restore-to-original behavior after translation.
- Automatic reuse of the last saved translation configuration on revisit.
- Section-level cache reuse when content has not changed significantly.

## 2. Implementation

### Backend

The backend is centered around a small translation pipeline exposed by `TranslationServlet`. The servlet accepts JSON requests from the browser, validates language inputs, resolves the active provider through `TranslationProviderFactory`, and delegates section-based translation work to `TranslationCacheService`.

`TranslationCacheService` is the core optimization for Task 5B. It computes a SHA-256 hash over normalized section text, where normalization trims leading and trailing whitespace and collapses repeated whitespace. Because of that, cosmetic spacing changes do not invalidate the cache, but actual content edits do. The cache key includes provider, source language, target language, and content hash, so translations are reused only when the effective translation request is truly the same.

Language handling is centralized in `TranslationLanguageSupport`, which normalizes values such as `en-US` or `mr_IN` into the supported internal codes and maps those codes to provider-specific formats for Sarvam such as `mr-IN`. The provider layer is implemented through the `TranslationProvider` strategy interface with `MyMemoryTranslationProvider` and `SarvamTranslationProvider` as concrete implementations.

The following class diagram summarizes the implemented subsystem:

![Task 5 Translation System Class Diagram](task5-translation-system-class-diagram.png)

Implemented backend behavior:

- `TranslationServlet` supports both section-based requests and the older text-list request format.
- `TranslationProviderFactory` chooses the provider and falls back to `mymemory` for unknown names.
- `TranslationCacheService` reuses cached section translations and retranslates only changed sections.
- `TranslationLanguageSupport` centralizes supported-language checks and provider-specific code mapping.
- `SarvamTranslationProvider` reads the API key from Roller configuration and falls back to `translation-api.properties` if needed.
- `MyMemoryTranslationProvider` and `SarvamTranslationProvider` both translate text in batches while preserving item order in the response.

### Frontend (screenshots)

The frontend is implemented as a shared JavaScript widget in `app/src/main/webapp/theme/scripts/translation.js` with styling in `app/src/main/webapp/theme/styles/translation.css`. The widget is injected on page load, detects the source language from the page `lang` attribute or URL, scans the primary visible content, groups text nodes into sections, and sends only those sections to the backend translation endpoint.

The widget also stores the most recent translation configuration in local storage, supports restore-to-original behavior, and automatically reapplies the saved translation on revisit. Theme templates opt in by including the shared script and stylesheet and by exposing the correct `lang` attribute on the page.

The repository does not currently include committed Task 5 UI screenshots, so the report-ready screenshot slots for this section are:

1. Public weblog page with the translation widget visible.
2. Same page after translating to Hindi or Marathi.
3. Revisit flow showing the cached-section status message.
4. Provider switch example showing `MyMemory` and `Sarvam AI`.

Suggested pages for capture:

- `basic/weblog` or `basic/permalink`
- `fauxcoly/search`
- `gaurav/archives`
- `frontpage`

## 3. Assumptions / Constraints

- Translation is currently available only on public theme views that include the shared translation assets.
- The supported languages are limited to `en`, `hi`, `bn`, `ta`, `te`, `kn`, and `mr`.
- Source auto-detection uses the page `lang` attribute first, then path-based hints, and finally falls back to `en`.
- Only rendered text nodes are translated. The implementation does not translate images, links, HTML attributes, or dynamically excluded UI regions.
- The cache is an in-memory server-side cache inside `TranslationCacheService`, so it is process-local and not persisted across restarts.
- Cache reuse is based on normalized text content, provider, source language, and target language.
- Sarvam translation requires a configured API key. If it is missing, Sarvam requests fail and the feature should be used with `MyMemory` or configured credentials.
- The current frontend integration focuses on weblog-facing views rather than every possible Roller page type.

## 4. Files Modified / Added

### Backend

- `app/src/main/java/org/apache/roller/weblogger/ui/rendering/servlets/TranslationServlet.java`
- `app/src/main/java/org/apache/roller/weblogger/ui/rendering/servlets/TranslationCacheService.java`
- `app/src/main/java/org/apache/roller/weblogger/ui/rendering/servlets/TranslationLanguageSupport.java`
- `app/src/main/java/org/apache/roller/weblogger/ui/rendering/servlets/TranslationProvider.java`
- `app/src/main/java/org/apache/roller/weblogger/ui/rendering/servlets/TranslationProviderFactory.java`
- `app/src/main/java/org/apache/roller/weblogger/ui/rendering/servlets/MyMemoryTranslationProvider.java`
- `app/src/main/java/org/apache/roller/weblogger/ui/rendering/servlets/SarvamTranslationProvider.java`
- `app/src/main/java/org/apache/roller/weblogger/ui/rendering/servlets/TranslationSectionRequest.java`
- `app/src/main/java/org/apache/roller/weblogger/ui/rendering/servlets/TranslationSectionResponse.java`
- `app/src/main/webapp/WEB-INF/web.xml`
- `app/src/main/resources/org/apache/roller/weblogger/config/roller.properties`

### Frontend

- `app/src/main/webapp/theme/scripts/translation.js`
- `app/src/main/webapp/theme/styles/translation.css`

### Theme Integration

- `app/src/main/webapp/themes/basic/weblog.vm`
- `app/src/main/webapp/themes/basic/permalink.vm`
- `app/src/main/webapp/themes/basic/searchresults.vm`
- `app/src/main/webapp/themes/basicmobile/weblog.vm`
- `app/src/main/webapp/themes/basicmobile/weblog-mobile.vm`
- `app/src/main/webapp/themes/basicmobile/permalink.vm`
- `app/src/main/webapp/themes/basicmobile/permalink-mobile.vm`
- `app/src/main/webapp/themes/basicmobile/searchresults.vm`
- `app/src/main/webapp/themes/basicmobile/searchresults-mobile.vm`
- `app/src/main/webapp/themes/fauxcoly/weblog.vm`
- `app/src/main/webapp/themes/fauxcoly/entry.vm`
- `app/src/main/webapp/themes/fauxcoly/search.vm`
- `app/src/main/webapp/themes/fauxcoly/tags_index.vm`
- `app/src/main/webapp/themes/fauxcoly/archives.vm`
- `app/src/main/webapp/themes/gaurav/weblog.vm`
- `app/src/main/webapp/themes/gaurav/entry.vm`
- `app/src/main/webapp/themes/gaurav/search.vm`
- `app/src/main/webapp/themes/gaurav/tags_index.vm`
- `app/src/main/webapp/themes/gaurav/archives.vm`
- `app/src/main/webapp/themes/frontpage/_header.vm`
- `app/src/main/webapp/themes/frontpage/_footer.vm`

### Tests and Documentation

- `app/src/test/java/org/apache/roller/weblogger/ui/rendering/servlets/TranslationCacheServiceTest.java`
- `app/src/test/java/org/apache/roller/weblogger/ui/rendering/servlets/TranslationLanguageSupportTest.java`
- `docs/task5-translation-system.md`
- `docs/task5-translation-system-class-diagram.puml`
- `docs/task5-translation-system-class-diagram.png`

## 5. Design Patterns

- Strategy Pattern
  Used through `TranslationProvider`, `MyMemoryTranslationProvider`, and `SarvamTranslationProvider`.
- Factory Pattern
  Used through `TranslationProviderFactory`.
- Cache Pattern
  Used through `TranslationCacheService`.
- Adapter-Like Normalization Pattern
  Used through `TranslationLanguageSupport` to bridge frontend codes and provider-specific codes.
- Template Method Style Request Flow
  Used in `TranslationServlet`, which follows a fixed request-handling sequence while delegating variable steps outward.

## 6. Rationale Behind Pattern

- Strategy was chosen because provider-specific HTTP calls, credentials, and language mappings differ, but the servlet should depend on one stable translation contract.
- Factory was chosen so provider selection stays centralized and new providers can be added without scattering construction logic through the servlet or widget flow.
- Cache was chosen because Task 5B explicitly requires avoiding repeated translation work for unchanged content, and section-level reuse gives better efficiency than retranslating an entire page.
- The normalization layer was chosen because the UI, internal backend flow, and Sarvam provider use slightly different language-code representations.
- The template-method-style servlet flow keeps request processing predictable: parse input, normalize languages, choose provider, consult cache, translate misses, and return JSON.

## 7. User Flow

1. A reader opens a public Roller page that includes the shared translation widget.
2. On page load, `translation.js` injects the widget, detects the likely source language, and restores the last saved configuration from local storage.
3. The reader selects a target language and provider, or keeps the saved values.
4. The widget scans the primary visible content, groups text nodes into sections, and sends those sections to `/roller-services/translate`.
5. `TranslationServlet` normalizes the language codes, resolves the provider, and forwards the request to `TranslationCacheService`.
6. `TranslationCacheService` checks the in-memory cache using the normalized content hash of each section.
7. Cached sections are reused immediately, while only cache misses are sent to the chosen translation provider.
8. The backend returns translated sections plus cache metadata to the browser.
9. The widget replaces only the original text nodes in the DOM, leaving page structure, styling, images, and navigation unchanged.
10. The selected configuration is saved locally so the same translation can be auto-applied on the next visit.
11. If the underlying weblog content changes, only the changed sections are retranslated while unchanged sections continue to reuse cached results.

## 8. UML Class Diagram

![Task 5 Translation System Class Diagram](task5-translation-system-class-diagram.png)